import Cookies from 'js-cookie';
import Vue from 'vue';

const user = {
    state: {
        permissionList: null,
        actionPermissionList: []
    },
    mutations: {
        logout(state, vm) {
            Cookies.remove('user');
            Cookies.remove('password');
            Cookies.remove('access');
            // 恢复默认样式
            let themeLink = document.querySelector('link[name="theme"]');
            themeLink.setAttribute('href', '');
            // 清空打开的页面等数据，但是保存主题数据
            let theme = '';
            if (localStorage.theme) {
                theme = localStorage.theme;
            }
            localStorage.clear();
            if (theme) {
                localStorage.theme = theme;
            }
            state.permissionList = null;
            state.actionPermissionList = [];
        },
        changePermissions(state, permissionList) {
            state.permissionList = permissionList;
        },
        changeActionPermissions(state, actionPermission) {
            state.actionPermissionList.push(actionPermission);
        },
        clearPermissions(state) {
            state.permissionList = null;
            state.actionPermissionList = [];
        }
    },
    actions: {
        setMenuPermissions: ({dispatch, commit}) => {
            return new Promise((resolve, reject) => {
                Vue.http.get('/api-csboss/home/menuList.html', null)
                    .then((response) => {
                            let menus = response.body;
                            commit("changePermissions", menus);
                            dispatch('setActionPermissions', {menus: menus,resolve : resolve});
                        },
                        (error) => {
                            console.log(error)
                            resolve('error');
                        });
            });
        },
        /**
         * 获取action权限
         * @param commit
         * @param menus
         */
        setActionPermissions: ({commit}, {menus,resolve}) => {
            //TODO 从服务端获取action权限
            let action = {
                menu: '', //所属菜单
                actions: []
            }
            commit('changeActionPermissions', action);
            resolve('success');
        }
    },
    getters: {
        /**
         * 是否有菜单权限
         * @param state
         * @returns {function(*): *}
         */
        hasMenuPermission: (state) => (item) => {
            if (state.permissionList && state.permissionList.length > 0) {
                if (item.access === 1) {
                    if (!state.permissionList.includes(item.props.permission)) {
                        return false;
                    }
                }
            } else {
                return false;
            }
            return true;
        },
        /**
         * 是否有功能权限
         * @param state
         * @returns {function(*): *}
         */
        hasActionPermission: (state) => (menu, action) => {
            //return state.actionPermissionList.find(p => p.menu === menu && p.actions.includes(action) != null);
            return true;
        }
    }
};

export default user;
