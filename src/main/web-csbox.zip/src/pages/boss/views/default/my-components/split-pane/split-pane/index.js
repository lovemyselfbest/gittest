import splitPane from './split-pane.vue';

export default splitPane;
