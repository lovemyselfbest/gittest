export const columns1 = [
    {
        key: 'name',
        title: '姓名'
    },
    {
        key: 'tel',
        title: '电话号码'
    }
];

export const searchTable1 = [
    {
        name: 'Aresn',
        tel: '17712345678'
    },
    {
        name: 'Lison',
        tel: '17787654321'
    },
    {
        name: 'Lili',
        tel: '12212345678'
    },
    {
        name: 'Lucy',
        tel: '13312345678'
    }
];

export const searchTable2 = [
    {
        name: 'Aresn',
        tel: '17712345678'
    },
    {
        name: 'Lison',
        tel: '17787654321'
    },
    {
        name: 'Lili',
        tel: '12212345678'
    },
    {
        name: 'Lucy',
        tel: '13312345678'
    }
];

export const searchTable3 = [
    {
        name: 'Aresn',
        tel: '17712345678'
    },
    {
        name: 'Lison',
        tel: '17787654321'
    },
    {
        name: 'Lili',
        tel: '12212345678'
    },
    {
        name: 'Lucy',
        tel: '13312345678'
    }
];
