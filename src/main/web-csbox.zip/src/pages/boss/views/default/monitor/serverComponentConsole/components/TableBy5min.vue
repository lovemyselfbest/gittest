<!--
*
* @description: 
*
* @author: nick
*
* @create: 2018-05-22 20:27
-->
<style lang="less" scoped>
    @import '../css/monitor-table.less';
</style>
<style lang="less">
    @import '../css/monitor-table-global.less';
</style>
<template>
    <!--<Table border :columns="fiveMinuteColumn" :data="fiveMinuteGridData" size="small"></Table>-->
    <div class="ivu-table-wrapper">
        <div class="ivu-table ivu-table-small ivu-table-border">
            <div class="ivu-table-header">
                <table cellspacing="0" cellpadding="0" border="0" style="width:100%;">
                    <colgroup>
                        <template v-for="index of fiveMinuteColumn.length">
                            <col width="">
                        </template>
                    </colgroup>
                    <thead>
                    <tr>
                        <template v-for="column of fiveMinuteColumn">
                            <th class="">
                                <div class="ivu-table-cell"><span>{{column.title}}</span></div>
                            </th>
                        </template>
                    </tr>
                    </thead>
                </table>
            </div>
            <div class="ivu-table-body" :hidden="fiveMinuteGridData.length === 0">
                <table cellspacing="0" cellpadding="0" border="0" style="width:100%;">
                    <colgroup>
                        <template v-for="index of fiveMinuteColumn.length">
                            <col width="">
                        </template>
                    </colgroup>
                    <!-- <tbody class="ivu-table-tbody"></tbody>-->
                    <tbody class="ivu-table-tbody">
                    <template v-for="(countTimeO,countTimeIndex) in fiveMinuteGridData">
                        <template v-for="(hosts,countTime) in countTimeO">
                            <template v-for="(applications,host,hostIndex) in hosts">
                                <template v-for="(components,application,applicationIndex) in applications">
                                    <template v-for="(sites,component,componentsIndex) in components">
                                        <template v-for="(actions,site) in sites">
                                            <template v-for="d in actions">
                                                <tr class="ivu-table-row" :class="{'data-error' : d.errorCount > 0}">
                                                    <template v-if="validBegin(1,countTimeIndex)">
                                                        <td class="" :rowspan="getRowSpan(1,countTimeO)">
                                                            <div class="ivu-table-cell">
                                                                <span>{{formatDate(countTime)}}</span>
                                                            </div>
                                                        </td>
                                                    </template>
                                                    <template v-if="validBegin(2,countTimeIndex + '_'+ hostIndex)">
                                                        <td class=""
                                                            :rowspan="getRowSpan(2,applications)">
                                                            <div class="ivu-table-cell"><span>{{host}}</span>
                                                            </div>
                                                        </td>
                                                    </template>
                                                    <template
                                                            v-if="validBegin(3,countTimeIndex + '_'+ hostIndex + '_'+ applicationIndex)">
                                                        <td class=""
                                                            :rowspan="getRowSpan(3,components)">
                                                            <div class="ivu-table-cell"><span>{{application}}</span>
                                                            </div>
                                                        </td>
                                                    </template>
                                                    <template
                                                            v-if="validBegin(4,countTimeIndex + '_'+ hostIndex + '_'+ applicationIndex + '_'+ componentsIndex)">
                                                        <td class=""
                                                            :rowspan="getRowSpan(4,sites)">
                                                            <div class="ivu-table-cell"><span>{{component}}</span></div>
                                                        </td>
                                                    </template>
                                                    <td class="">
                                                        <div class="ivu-table-cell"><span>{{site == -1 ? '' : site}}</span></div>
                                                    </td>
                                                    <td class="">
                                                        <div class="ivu-table-cell"><span>{{d.action}}</span></div>
                                                    </td>
                                                    <td class="">
                                                        <div class="ivu-table-cell"><span>{{d.actionKey}}</span>
                                                        </div>
                                                    </td>
                                                    <td class="">
                                                        <div class="ivu-table-cell"><span class="active-count-cls run-animation-data-updated" :key="d.activeCount">{{d.activeCount}}</span></div>
                                                    </td>
                                                    <td class="">
                                                        <div class="ivu-table-cell"><span>{{d.errorCount}}</span></div>
                                                    </td>
                                                    <td class="">
                                                        <div class="ivu-table-cell"><span>{{d.minResponseTime}}</span>
                                                        </div>
                                                    </td>
                                                    <td class="">
                                                        <div class="ivu-table-cell"><span>{{d.maxResponseTime}}</span>
                                                        </div>
                                                    </td>
                                                    <td class="">
                                                        <div class="ivu-table-cell"><span>{{d.lastActiveTimeStr}}</span>
                                                        </div>
                                                    </td>
                                                    <td class="">
                                                        <div class="ivu-table-cell">
                                                            <span>
                                                                <template v-if="d.errorCount > 0">
                                                                    <Poptip trigger="hover" placement="left-end"
                                                                            width="1400" :transfer="poptipTransfer">
                                                                        <Button>查看异常</Button>
                                                                        <div class="api" slot="content">
                                                                        <table class="error-table">
                                                                            <thead>
                                                                                <tr>
                                                                                    <th>OwnerClass</th>
                                                                                    <th>ErrorMessage</th>
                                                                                    <th>Exception</th>
                                                                                </tr>
                                                                            </thead>
                                                                            <tbody>
                                                                                <template v-for="(errors,actionKey) of d.errorInfoMap">
                                                                                    <template v-for="(error,errorKey) of errors">
                                                                                        <tr>
                                                                                            <td>{{errorKey.split(":")[0]}}</td>
                                                                                            <td>{{error.errorMessage}}</td>
                                                                                            <td>
                                                                                                <template
                                                                                                        v-for="(err,index) of error.exception"
                                                                                                        v-if="index < 5">
                                                                                                        className : {{err.className}},fileName : {{err.fileName}},lineNumber : {{err.lineNumber}},methodName : {{err.methodName}},nativeMethod : {{err.nativeMethod}}
                                                                                                        <br>
                                                                                                </template>
                                                                                            </td>
                                                                                        </tr>
                                                                                     </template>
                                                                                </template>
                                                                            </tbody>
                                                                        </table>
                                                                        </div>
                                                                    </Poptip>
                                                                </template>
                                                            </span>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </template>
                                        </template>
                                    </template>
                                </template>
                            </template>
                        </template>
                    </template>
                    </tbody>
                </table>
            </div>
            <div class="ivu-table-tip" :hidden="fiveMinuteGridData.length > 0">
                <table cellspacing="0" cellpadding="0" border="0">
                    <tbody>
                    <tr>
                        <td><span>暂无数据</span></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</template>

<script>
    import moment from 'moment';
    import $ from 'jquery';
    let startIndex = {
        1: -1,
        2: -1,
        3: -1,
        4: -1
    };
    export default {
        name: "TableBy5min",
        props: [
            "fiveMinuteData",
            "searchData"
        ],
        data() {
            return {
                hiddenData: true,
                hiddenTip: false,
                poptipTransfer:true,
                fiveMinuteColumn: [
                    {
                        title: '统计时间',
                        key: 'countTime'
                    },
                    {
                        title: '主机',
                        key: 'ip'
                    },
                    {
                        title: '应用',
                        key: 'application'
                    },
                    {
                        title: '组件',
                        key: 'component'
                    },
                    {
                        title: '站点ID',
                        key: 'siteId'
                    },
                    {
                        title: 'Action',
                        key: 'action'
                    },
                    {
                        title: 'ActionKey',
                        key: 'actionKey'
                    },
                    {
                        title: '请求次数',
                        key: 'activeCount'
                    },
                    {
                        title: '出错次数',
                        key: 'errorCount'
                    },
                    {
                        title: '请求最短时间',
                        key: 'minResponseTime'
                    },
                    {
                        title: '请求最长时间',
                        key: 'maxResponseTime'
                    },
                    {
                        title: '最后请求时间',
                        key: 'lastActiveTimeStr'
                    },
                    {
                        title: '错误日志',
                        key: ''
                    }
                ],
                fiveMinuteGridData: []
            }
        },
        methods: {
            validBegin(level, index) {
                if (index != startIndex[level]) {
                    startIndex[level] = index;
                    return true;
                }
                return false;
            },
            getRowSpan(level, vo) {
                let size = 0;
                switch (level) {
                    case 1 :
                        Object.keys(vo).forEach((countTime) => {
                            let hosts = vo[countTime];
                            Object.keys(hosts).forEach((host) => {
                                let applications = hosts[host];
                                Object.keys(applications).forEach((application) => {
                                    let components = applications[application];
                                    Object.keys(components).forEach((component) => {
                                        let sites = components[component];
                                        Object.keys(sites).forEach((site) => {
                                            size += sites[site].length;
                                        });
                                    });
                                });
                            });
                        });
                        break;
                    case 2 :
                        Object.keys(vo).forEach((application) => {
                            let components = vo[application];
                            Object.keys(components).forEach((component) => {
                                let sites = components[component];
                                Object.keys(sites).forEach((site) => {
                                    size += sites[site].length;
                                });
                            });
                        });
                        break;
                    case 3 :
                        Object.keys(vo).forEach((component) => {
                            let sites = vo[component];
                            Object.keys(sites).forEach((site) => {
                                size += sites[site].length;
                            });
                        });
                        break;
                    case 4 :
                        Object.keys(vo).forEach((site) => {
                            size += vo[site].length;
                        });
                        break;
                    default :
                        break;
                }
                return size;
            },
            formatDate(date) {
                return moment(Number(date)).format('MM-DD HH:mm')
            },
            getDataByArr(arr, countTime) {
                let returnO;
                if (arr.length == 0) return null;
                arr.forEach((o) => {
                    let key = Object.keys(o)[0];
                    if (key === countTime) {
                        returnO = o;
                        return false;
                    }
                });
                return returnO;
            },
            setDataInArr(arr, countTime, host, application, component, site) {
                let countTimeO = this.getDataByArr(arr, countTime);
                if (!countTimeO) {
                    countTimeO = {
                        [countTime]: {
                            [host]: {
                                [application]: {
                                    [component]: {
                                        [site]: []
                                    }
                                }
                            }
                        }
                    };
                    arr.push(countTimeO);
                } else if (!countTimeO[countTime][host]) {
                    countTimeO[countTime][host] = {
                        [application]: {
                            [component]: {
                                [site]: []
                            }
                        }
                    }
                } else if (!countTimeO[countTime][host][application]) {
                    countTimeO[countTime][host][application] = {
                        [component]: {
                            [site]: []
                        }
                    }
                } else if (!countTimeO[countTime][host][application][component]) {
                    countTimeO[countTime][host][application][component] = {
                        [site]: []
                    }
                } else if (!countTimeO[countTime][host][application][component][site]) {
                    countTimeO[countTime][host][application][component][site] = [];
                }
            },
            dataUpdate(){
                return {
                    "-webkit-animation":"newData 7s 1 ease-in-out"
                }
            }
        },
        watch: {
            fiveMinuteData: function (val, oldVal) {
                let vm = this, arr = [], restart = true;
                startIndex[1] = -1;
                startIndex[2] = -1;
                startIndex[3] = -1;
                startIndex[4] = -1;
                Object.keys(val).forEach((countTime) => {
                    let hosts = val[countTime], hostArr = Object.keys(hosts);
                    hostArr.forEach((host) => {
                        let applications = hosts[host], applicationArr = Object.keys(applications);
                        applicationArr.forEach((application) => {
                            if(vm.searchData.applications.length === 0 || (vm.searchData.applications.length > 0 && vm.searchData.applications.indexOf(application) != -1)) {
                                let components = applications[application], componentArr = Object.keys(components);
                                componentArr.forEach((component) => {
                                    let sites = components[component], siteArr = Object.keys(sites);
                                    restart = true;
                                    siteArr.forEach((site) => {
                                        if(vm.searchData.siteId === '' || (vm.searchData.siteId != '' && site === vm.searchData.siteId)) {
                                            let actions = sites[site], actionArr = Object.keys(actions);
                                            actionArr.forEach((k) => {
                                                let action = actions[k];
                                                let data = {
                                                    action: action.action,
                                                    actionKey: action.actionKey,
                                                    result: action.result,
                                                    activeCount: action.activeCount,
                                                    lastActiveTime: action.lastActiveTime,
                                                    lastActiveTimeStr: moment(action.lastActiveTime).format('YYYY-MM-DD HH:mm:ss'),
                                                    lastErrorTime: action.lastErrorTime,
                                                    maxResponseTime: action.maxResponseTime,
                                                    minResponseTime: action.minResponseTime,
                                                    owner: action.owner,
                                                    totalResponseTime: action.totalResponseTime,
                                                    errorCount: action.errorCount,
                                                    errorInfoMap: action.errorInfoMap
                                                };
                                                vm.setDataInArr(arr, action.countTime, host, application, component, site);
                                                let countTimeO = vm.getDataByArr(arr, action.countTime);
                                                let children = countTimeO[action.countTime][host][application][component][site];
                                                children.push(data);
                                            });
                                        }
                                    });
                                });
                            }
                        });
                    });
                });
                arr.sort((v1, v2) => {
                    let key1 = Object.keys(v1)[0];
                    let key2 = Object.keys(v2)[0];
                    if (key1 < key2) {
                        return 1;
                    }
                    if (key1 > key2) {
                        return -1;
                    }
                    return 0;
                });
                vm.fiveMinuteGridData = arr;
            }
        }
    }
</script>