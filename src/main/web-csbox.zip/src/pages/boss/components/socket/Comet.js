/**
 *
 */
import $ from 'jquery';

export default {
    name: 'Comet',
    last_active_time: new Date().getTime(),
    url: null,
    url_websocket: null,
    subscribes: [],
    cid: null,
    accept: function (data) {
        var comet = this;
        var message;
        if (typeof(data) == "object") {
            message = data;
        } else {
            message = eval("(" + data + ")");
        }
        //console.info("收到消息,消息内容为：" + data);
        var type = message.type;
        if (type === 'SubscribeData') {
            var subscribeType = message.body.dataType;
            $.each(comet.subscribes, function (i, val) {
                if (val.type == subscribeType) {
                    val.callback.call(val, data);
                    return false;
                }
            })
        }
        if (type === 'CommandResponse') {
            var subscribeType = message.body.commandType;
            $.each(comet.subscribes, function (i, val) {
                if (val.type == subscribeType) {
                    val.callback.call(val, data);
                    return false;
                }
            })
        }
    },
    /** 连接的语言类型参数名 */
    LOCALE_TYPE: "_LOCALE_TYPE",
    /** 连接的sessionID 参数名**/
    SESSION_KEY: "_SESSION_KEY",
    async: true,
    /** 是否在连接状态 */
    isConnect: false,
    /**订阅列表**/
    subscribes: [],
    /** 连接所需要传递的参数 **/
    userParam: {},
    /**连接成功后的回调函数**/
    successCallBack: function () {
    },
    /**连接失败后的回调函数**/
    failureCallBack: function () {
    },
    /**实例化后是否立即执行连接操作**/
    isImmediatelyConnect: false,
    /**是否使用websocket**/
    isUseWebsocket: false,
    websocket: null,
    /**
     * 构造器
     * @param props 参数对象
     */
    init: function (props) {
        var _this = this;
        _this.websocket = null;
        var wsProtocol = 'https:' == document.location.protocol ? "wss://" : "ws://";
        var wsPort = document.location.port != "" ? (":" + document.location.port) : "";
        _this.url_websocket = wsProtocol + document.domain + wsPort + "/csboss/websocket/console.ws?localeType=zh_CN";

        if ('WebSocket' in window) {
            _this.isUseWebsocket = true;
        }

        if (props.subscribes != undefined) {
            _this.subscribes = props.subscribes;
        }

        if (props.async != undefined) {
            _this.async = props.async;
        }
        if (props.accept != undefined) {
            _this.accept = props.accept;
        }
        if (props.success != undefined) {
            _this.successCallBack = props.success;
        }
        if (props.failure != undefined) {
            _this.failureCallBack = props.failure;
        }
        if (props.failure != undefined) {
            _this.isImmediatelyConnect = props.isImmediatelyConnect;
        }
        if (props.localeType != undefined) {
            _this.userParam[_this.LOCALE_TYPE] = props.localeType;
        }
        if (props.sessionKey != undefined) {
            _this.userParam[_this.SESSION_KEY] = props.sessionKey;
        }
        if (props.isImmediatelyConnect) {
            _this.connection();
        }
        //增加守护线程,防止异常终止
        window.setInterval(function () {
            if (new Date().getTime() - _this.last_active_time > 80000) {
                if (this.cid != undefined && this.cid != null) {
                    _this.userParam[_this.CONNECTIONID_KEY] = this.cid;
                }
                if (_this.websocket != null && _this.websocket.readyState == _this.websocket.OPEN) {
                    _this.websocket.send("");
                    _this.last_active_time = new Date().getTime();
                } else {
                    _this.connection();
                }
            }
        }, 10000);
    },
    /**
     * 开始链接
     *
     * @param userParam 连接时传递给服务器端的参数
     * @param successCallBack 连接成功处理方法
     * @param failureCallBack 连接失败处理方法
     * @param caller 调用者
     */
    connection: function (caller) {
        var _this = this;
        _this.last_active_time = new Date().getTime();
        if (_this.isUseWebsocket) {
            //如果socket正在连接或者已经连接，则返回
            if (_this.websocket != null &&
                (
                    _this.websocket.readyState == _this.websocket.CONNECTING
                    || _this.websocket.readyState == _this.websocket.OPEN
                )
            ) {
                return;
            }
            _this.websocket = new WebSocket(_this.url_websocket);
            _this.websocket.onopen = _this.onWebsocketOpen;
            _this.websocket.onclose = _this.onWebsocketClose;
            _this.websocket.onmessage = _this.onWebsocketMessage;
            _this.websocket.onerror = _this.onWebsocketError;
            _this.websocket.onbeforeunload = _this.onWebsocketBeforeUnload;
            _this.websocket.outThis = _this;
        } else {
            console.log("该浏览器不支持webSocket")
        }

    },

    acceptDatas: function (datas) {
        var len = datas.length;
        this.acceptDatasByLength(datas, len);

    },

    /**
     * 处理数组中指定长度的数据
     */
    acceptDatasByLength: function (datas, len) {
        for (var i = 0; i < len; i++) {
            var data = datas[i];
            this.accept(data, this.subscribes);
        }
    },
    onWebsocketOpen: function () {
        var outThis = this.outThis;
        if (outThis.successCallBack) {
            outThis.successCallBack.call();
        }
        outThis.isConnect = true;

    },
    onWebsocketMessage: function (event) {
        var outThis = this.outThis;
        var data = eval("(" + event.data + ")");
        outThis.acceptDatas(data);
    },
    onWebsocketClose: function () {
        var outThis = this.outThis;

    },
    onWebsocketError: function () {
        this.isConnect = false;
        console.log("socket error");
    },
    onWebsocketBeforeUnload: function () {
        console.log("socket before unload");
    }
};