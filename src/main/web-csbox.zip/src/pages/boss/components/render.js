export default {
    name: 'RenderCellByParams',
    functional: true,
    props: {
        render: Function,
        params:Array,
        labelText:String
    },
    render: (h, ctx) => {
        return ctx.props.render(h, ctx.props.params,ctx.props.labelText);
    }
};