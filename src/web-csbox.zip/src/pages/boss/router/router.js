import Main from './../views/Main.vue';
// 不作为Main组件的子页面展示的页面单独写，如下
export const loginRouter = {
    path: '/passport/login.html',
    name: 'login',
    meta: {
        title: 'Login - 登录'
    },
    component: () => import('./../views/default/login.vue'
        /* webpackChunkName: "./boss/default/login" */)
};

export const page404 = {
    path: '/*',
    name: 'error-404',
    meta: {
        title: '404-页面不存在'
    },
    component: () => import('./../views/default/error-page/404.vue'
        /* webpackChunkName: "./boss/default/error-page/404" */)
};

export const page403 = {
    path: '/403',
    meta: {
        title: '403-权限不足'
    },
    name: 'error-403',
    component: () => import('./../views/default/error-page/403.vue'
        /* webpackChunkName: "./boss/default/error-page/403" */)
};

export const page500 = {
    path: '/500',
    meta: {
        title: '500-服务端错误'
    },
    name: 'error-500',
    component: () => import('./../views/default/error-page/500.vue'
        /* webpackChunkName: "./boss/default/error-page/500" */)
};

export const preview = {
    path: '/preview',
    name: 'preview',
    component: () => import('./../views/default/form/article-publish/preview.vue'
        /* webpackChunkName: "./boss/default/form/article-publish/preview" */)
};

export const locking = {
    path: '/locking',
    name: 'locking',
    component: () => import('./../views/default/main-components/lockscreen/components/locking-page.vue'
        /* webpackChunkName: "./boss/default/main-components/lockscreen/components/locking-page" */)
};

// 作为Main组件的子页面展示但是不在左侧菜单显示的路由写在otherRouter里
export const otherRouter = {
    path: '/',
    name: 'otherRouter',
    redirect: '/home',
    component: Main,
    children: [
        { path: 'home', title: {i18n: 'home'}, name: 'home_index', component: () =>
                import('./../views/default/home/home.vue'
                    /* webpackChunkName: "./boss/default/home/home" */) },
        { path: 'ownspace', title: '个人中心', name: 'ownspace_index', component: () =>
                import('./../views/default/own-space/own-space.vue'
                    /* webpackChunkName: "./boss/default/own-space/own-space" */) },
        { path: 'order/:order_id', title: '订单详情', name: 'order-info', component: () =>
                import('./../views/default/advanced-router/component/order-info.vue'
                    /* webpackChunkName: "./boss/default/advanced-router/component/order-info" */) }, // 用于展示动态路由
        { path: 'shopping', title: '购物详情', name: 'shopping', component: () =>
                import('./../views/default/advanced-router/component/shopping-info.vue'
                    /* webpackChunkName: "./boss/default/advanced-router/component/shopping-info" */) }, // 用于展示带参路由
        { path: 'message', title: '消息中心', name: 'message_index', component: () =>
                import('./../views/default/message/message.vue' /* webpackChunkName: "./boss/default/message/message" */) }
    ]
};

// 作为Main组件的子页面展示并且在左侧菜单显示的路由写在appRouter里
export const appRouter = [
    {
        path: '/access',
        icon: 'key',
        name: 'access',
        title: '权限管理',
        component: Main,
        children: [
            { path: 'index', title: '权限管理', name: 'access_index', component: () =>
                    import('./../views/default/access/access.vue'
                        /* webpackChunkName: "./boss/default/access/access" */) }
        ]
    },
    {
        path: '/access-test',
        icon: 'lock-combination',
        title: '权限测试页',
        name: 'accesstest',
        access: 1,
        //permission : 'boss:serve',
        component: Main,
        children: [
            { path: 'test4', access: 0, title: '权限测试页4', name: 'accesstest_4', component: () =>
                    import('./../views/default/access/access-test.vue'
                        /* webpackChunkName: "./boss/default/access/access-test" */) },
            { path: 'test1', access: 1,props: {permission : 'boss:serve'}, title: '权限测试页1', name: 'accesstest_1',component: () =>
                    import('./../views/default/access/access-test.vue'
                        /* webpackChunkName: "./boss/default/access/access-test" */) },
            { path: 'test2', access: 1,props: {permission : 'serve:announcement'}, title: '权限测试页2', name: 'accesstest_2', component: () =>
                    import('./../views/default/access/access-test2.vue'
                        /* webpackChunkName: "./boss/default/access/access-test2" */) },
            { path: 'test3', access: 1,props: {permission : 'no:permission'}, title: '权限测试页3', name: 'accesstest_3', component: () =>
                    import('./../views/default/access/access-test.vue'
                        /* webpackChunkName: "./boss/default/access/access-test" */) }

        ]
    },
    {
        path: '/monitor',
        icon: 'usb',
        title: '运维',
        name: 'monitor',
        access: 1,
        //permission : 'boss:serve',
        component: Main,
        children: [
            { path: 'versionSwitch', access: 1, title: '服务版本切换', name: 'monitor_tab', props: { permission:"maintenance:monitor:vresion" },
                component: () =>
                    import('./../views/default/monitor/serverVersion/monitor-tab.vue'
                        /* webpackChunkName: "./boss/default/monitor/serverVersion/monitor-tab" */) },
            { path: 'serverComponentConsole', access: 1, title: '组件监控', name: 'monitor_console',props: { permission:"maintenance:monitor" },
                component: () =>
                    import('./../views/default/monitor/serverComponentConsole/monitor-comp.vue'
                        /* webpackChunkName: "./boss/default/monitor/serverComponentConsole/monitor-comp" */) }
        ],
        listeners:[

        ]
    },
    {
        path: '/international',
        icon: 'earth',
        title: {i18n: 'international'},
        name: 'international',
        component: Main,
        children: [
            { path: 'index', title: {i18n: 'international'}, name: 'international_index',
                component: () =>
                    import('./../views/default/international/international.vue'
                        /* webpackChunkName: "./boss/default/international/international" */) }
        ]
    },
    {
        path: '/component',
        icon: 'social-buffer',
        name: 'component',
        title: '组件',
        component: Main,
        children: [
            {
                path: 'text-editor',
                icon: 'compose',
                name: 'text-editor',
                title: '富文本编辑器',
                component: () =>
                    import('./../views/default/my-components/text-editor/text-editor.vue'
                        /* webpackChunkName: "./boss/default/my-components/text-editor/text-editor" */)
            },
            {
                path: 'md-editor',
                icon: 'pound',
                name: 'md-editor',
                title: 'Markdown编辑器',
                component: () =>
                    import('./../views/default/my-components/markdown-editor/markdown-editor.vue'
                        /* webpackChunkName: "./boss/default/my-components/markdown-editor/markdown-editor" */)
            },
            {
                path: 'image-editor',
                icon: 'crop',
                name: 'image-editor',
                title: '图片预览编辑',
                component: () =>
                    import('./../views/default/my-components/image-editor/image-editor.vue'
                        /* webpackChunkName: "./boss/default/my-components/image-editor/image-editor" */)
            },
            {
                path: 'draggable-list',
                icon: 'arrow-move',
                name: 'draggable-list',
                title: '可拖拽列表',
                component: () =>
                    import('./../views/default/my-components/draggable-list/draggable-list.vue'
                        /* webpackChunkName: "./boss/default/my-components/draggable-list/draggable-list" */)
            },
            {
                path: 'area-linkage',
                icon: 'ios-more',
                name: 'area-linkage',
                title: '城市级联',
                component: () =>
                    import('./../views/default/my-components/area-linkage/area-linkage.vue'
                        /* webpackChunkName: "./boss/default/my-components/area-linkage/area-linkage" */)
            },
            {
                path: 'file-upload',
                icon: 'android-upload',
                name: 'file-upload',
                title: '文件上传',
                component: () =>
                    import('./../views/default/my-components/file-upload/file-upload.vue'
                        /* webpackChunkName: "./boss/default/my-components/file-upload/file-upload" */)
            },
            {
                path: 'count-to',
                icon: 'arrow-graph-up-right',
                name: 'count-to',
                title: '数字渐变',
                // component: () => import('./../views/default/my-components/count-to/count-to.vue' /* webpackChunkName: "./boss/default/login" */)
                component: () =>
                    import('./../views/default/my-components/count-to/count-to.vue'
                        /* webpackChunkName: "./boss/default/my-components/count-to/count-to" */)
            },
            {
                path: 'split-pane-page',
                icon: 'ios-pause',
                name: 'split-pane-page',
                title: 'split-pane',
                component: () =>
                    import('./../views/default/my-components/split-pane/split-pane-page.vue'
                        /* webpackChunkName: "./boss/default/my-components/split-pane/split-pane-page" */)
            }
        ]
    },
    {
        path: '/form',
        icon: 'android-checkbox',
        name: 'form',
        title: '表单编辑',
        component: Main,
        children: [
            { path: 'artical-publish', title: '文章发布', name: 'artical-publish', icon: 'compose',
                component: () =>
                    import('./../views/default/form/article-publish/article-publish.vue'
                        /* webpackChunkName: "./boss/default/form/article-publish/article-publish" */) },
            { path: 'workflow', title: '工作流', name: 'workflow', icon: 'arrow-swap',
                component: () =>
                    import('./../views/default/form/work-flow/work-flow.vue'
                        /* webpackChunkName: "./boss/default/form/work-flow/work-flow" */) }

        ]
    },
    // {
    //     path: '/charts',
    //     icon: 'ios-analytics',
    //     name: 'charts',
    //     title: '图表',
    //     component: Main,
    //     children: [
    //         { path: 'pie', title: '饼状图', name: 'pie', icon: 'ios-pie', component: resolve => { require('./../views/default/access/access.vue' /* webpackChunkName: "./boss/default/login" */) },
    //         { path: 'histogram', title: '柱状图', name: 'histogram', icon: 'stats-bars', component: resolve => { require('./../views/default/access/access.vue' /* webpackChunkName: "./boss/default/login" */) }

    //     ]
    // },
    {
        path: '/tables',
        icon: 'ios-grid-view',
        name: 'tables',
        title: '表格',
        component: Main,
        children: [
            { path: 'dragableTable', title: '可拖拽排序', name: 'dragable-table', icon: 'arrow-move',
                component: () => import('./../views/default/tables/dragable-table.vue'
                    /* webpackChunkName: "./boss/default/tables/dragable-table" */) },
            { path: 'editableTable', title: '可编辑表格', name: 'editable-table', icon: 'edit',
                component: () => import('./../views/default/tables/editable-table.vue'
                    /* webpackChunkName: "./boss/default/tables/editable-table" */) },
            { path: 'searchableTable', title: '可搜索表格', name: 'searchable-table', icon: 'search',
                component: () => import('./../views/default/tables/searchable-table.vue'
                    /* webpackChunkName: "./boss/default/tables/searchable-table" */) },
            { path: 'exportableTable', title: '表格导出数据', name: 'exportable-table', icon: 'code-download',
                component: () => import('./../views/default/tables/exportable-table.vue'
                    /* webpackChunkName: "./boss/default/tables/exportable-table" */) },
            { path: 'table2image', title: '表格转图片', name: 'table-to-image', icon: 'images',
                component: () => import('./../views/default/tables/table-to-image.vue'
                    /* webpackChunkName: "./boss/default/tables/table-to-image" */) }
        ]
    },
    {
        path: '/advanced-router',
        icon: 'ios-infinite',
        name: 'advanced-router',
        title: '高级路由',
        component: Main,
        children: [
            { path: 'mutative-router', title: '动态路由', name: 'mutative-router', icon: 'link',
                component: () =>
                    import('./../views/default/advanced-router/mutative-router.vue'
                        /* webpackChunkName: "./boss/default/advanced-router/mutative-router" */) },
            { path: 'argument-page', title: '带参页面', name: 'argument-page', icon: 'android-send',
                component: () =>
                    import('./../views/default/advanced-router/argument-page.vue'
                        /* webpackChunkName: "./boss/default/advanced-router/argument-page" */) }
        ]
    },
    {
        path: '/error-page',
        icon: 'android-sad',
        title: '错误页面',
        name: 'errorpage',
        component: Main,
        children: [
            { path: 'index', title: '错误页面', name: 'errorpage_index',
                component: () =>
                    import('./../views/default/error-page/error-page.vue'
                        /* webpackChunkName: "./boss/default/error-page/error-page" */) }
        ]
    }
];

// 所有上面定义的路由都要写在下面的routers里
export const routers = [
    loginRouter,
    otherRouter,
    preview,
    locking,
    ...appRouter,
    page500,
    page403,
    page404
];
