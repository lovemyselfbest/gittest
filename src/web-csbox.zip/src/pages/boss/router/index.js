import Vue from 'vue';
import iView from 'iview';
import Util from '@/libs/util';
import VueRouter from 'vue-router';
import Cookies from 'js-cookie';
import User from '../store/modules/user';
import VueResource from 'vue-resource'

Vue.use(VueResource);
Vue.use(VueRouter);

// 路由配置
const RouterConfig = {
    // mode: 'history',
    routes: routers
};

import {routers, otherRouter, appRouter} from './router';

export const router = new VueRouter(RouterConfig);

function doBeforeEach(to, from, next) {
    // 这里写sleep之后需要去做的事情
    iView.LoadingBar.start();
    Util.title(to.meta.title);
    if (Cookies.get('locking') === '1' && to.name !== 'locking') { // 判断当前是否是锁定状态
        next({
            replace: true,
            name: 'locking'
        });
    } else if (Cookies.get('locking') === '0' && to.name === 'locking') {
        next(false);
    } else {
        if (!Cookies.get('user') && to.name !== 'login') { // 判断是否已经登录且前往的页面不是登录页
            next({
                name: 'login'
            });
        } else if (Cookies.get('user') && to.name === 'login') { // 判断是否已经登录且前往的是登录页
            Util.title();
            next({
                name: 'home_index'
            });
        } else {
            const curRouterObj = Util.getRouterObjByName([otherRouter, ...appRouter], to.name);
            if (curRouterObj && curRouterObj.access == 1) { // 需要判断权限的路由
                if (User.state.permissionList && curRouterObj.props && !User.state.permissionList.includes(curRouterObj.props.permission)) {
                    next({
                        //replace: true,
                        name: 'error-403'
                    });
                } else {
                    Util.toDefaultPage([otherRouter, ...appRouter], to.name, router, next); // 如果在地址栏输入的是一级菜单则默认打开其第一个二级菜单的页面
                }
            } else { // 没有配置权限的路由, 直接通过
                Util.toDefaultPage([...routers], to.name, router, next);
            }
        }
    }
}
router.beforeEach((to, from, next) => {
    //前段多模板的实现入口
    if(!window.top.templateName){
        Vue.http.get('/api-csboss/home/siteParam.html',{async:false}).then((response)=>{
                window.top.templateName=response.body;
                doBeforeEach(to, from, next);
            },
            (error)=>{
                console.log(error);
                window.top.templateName="default";
                doBeforeEach(to, from, next);
            });
    }else{
        doBeforeEach(to, from, next);
    }
});

router.afterEach((to) => {
    Util.openNewPage(router.app, to.name, to.params, to.query);
    iView.LoadingBar.finish();
    window.scrollTo(0, 0);
});
