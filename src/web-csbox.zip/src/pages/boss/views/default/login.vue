<style lang="less">
    @import './login.less';
</style>

<template>
    <div class="login" @keydown.enter="handleSubmit">
        <div class="login-con">
            <Card :bordered="false">
                <p slot="title">
                    <Icon type="log-in"></Icon>
                    欢迎登录
                </p>
                <div class="form-con">
                    <Form ref="loginForm" :model="form" :rules="rules">
                        <FormItem prop="username">
                            <Input v-model="form.username" placeholder="请输入用户名">
                            <span slot="prepend">
                                    <Icon :size="16" type="person"></Icon>
                                </span>
                            </Input>
                        </FormItem>
                        <FormItem prop="password">
                            <Input type="password" v-model="form.password" placeholder="请输入密码">
                            <span slot="prepend">
                                    <Icon :size="14" type="locked"></Icon>
                                </span>
                            </Input>
                        </FormItem>
                        <FormItem prop="authentication">
                            <Input v-model="form.authentication" placeholder="请输入身份验证码">
                            <span slot="prepend">
                                    <Icon :size="14" type="locked"></Icon>
                                </span>
                            </Input>
                        </FormItem>
                        <FormItem>
                            <Button @click="handleSubmit" type="primary" long>登录</Button>
                        </FormItem>
                    </Form>
                    <p class="login-tip">输入任意用户名和密码即可</p>
                </div>
            </Card>
        </div>
    </div>
</template>

<script>
    import Cookies from 'js-cookie';
    import util from '@/libs/util';

    export default {
        name: "login",
        data() {
            return {
                form: {
                    username: '',
                    password: '',
                    authentication: ''
                },
                rules: {
                    username: [
                        {required: true, message: '账号不能为空', trigger: 'blur'}
                    ],
                    password: [
                        {required: true, message: '密码不能为空', trigger: 'blur'}
                    ],
                    authentication: [
                        {required: true, message: '身份验证码不能为空', trigger: 'blur'}
                    ]
                }
            };
        },
        methods: {
            handleSubmit() {
                let vm = this;
                vm.$refs.loginForm.validate((valid) => {
                    if (valid) {
                        let formData = vm.form;
                        vm.$http.post('/api-csboss/passport/login.html', formData, {emulateJSON: true})
                            .then((response) => {
                                    if (response.body.success) {
                                        Cookies.set('user', this.form.username);
                                        Cookies.set('password', this.form.password);
                                        vm.$store.commit('setAvator', 'https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3448484253,3685836170&fm=27&gp=0.jpg');
                                        if (formData.username === 'iview_admin') {
                                            Cookies.set('access', 0);
                                        } else {
                                            Cookies.set('access', 1);
                                        }
                                        vm.$router.push({
                                            name: 'home_index'
                                        });
                                    } else {
                                        vm.$Message.error({content:response.body.message});
                                    }
                                },
                                (error) => {
                                    console.log(error)
                                });
                        /*Cookies.set('user', this.form.userName);
                        Cookies.set('password', this.form.password);
                        this.$store.commit('setAvator', 'https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3448484253,3685836170&fm=27&gp=0.jpg');
                        if (this.form.userName === 'iview_admin') {
                            Cookies.set('access', 0);
                        } else {
                            Cookies.set('access', 1);
                        }

                        let appRouter11 = [
                            {
                                path: '/dda',
                                icon: 'key',
                                name: 'dda',
                                title: 'xxa管理',
                                component:() => import('@/views/form/work-flow/work-flow.vue')
                            }
                        ];
                        this.$router.addRoutes(appRouter11);*/


                    }
                });
            }
        }
    };
</script>

<style>

</style>
