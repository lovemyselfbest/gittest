<!--
*
* @description: 
*
* @author: nick
*
* @create: 2018-05-22 20:27
-->
<style lang="less" scoped>
    @import '../css/monitor-table.less';
</style>
<style lang="less">
    @import '../css/monitor-table-global.less';
</style>
<template>
    <!--<Table :columns="realTimeColumn" :data="realTimeGridData" size="small" :loading="dataLoading"></Table>-->
    <div class="ivu-table ivu-table-small">
        <div class="ivu-table-header">
            <table cellspacing="0" cellpadding="0" border="0" style="width: 100%">
                <colgroup>
                    <template v-for="index of realTimeColumn.length">
                        <col width="">
                    </template>
                </colgroup>
                <thead>
                <tr>
                    <template v-for="column of realTimeColumn">
                        <th class="">
                            <div class="ivu-table-cell"><span>{{column.title}}</span></div>
                        </th>
                    </template>
                </tr>
                </thead>
            </table>
        </div>
        <div class="ivu-table-body" style="display: none;" :id="table.tableId">
            <table cellspacing="0" cellpadding="0" border="0" style="width: 100%;">
                <template v-for="index of realTimeColumn.length">
                    <col width="">
                </template>
                <tbody class="ivu-table-tbody"></tbody>
            </table>
        </div>
        <div class="ivu-table-tip" :id="table.tipId" :hidden="tipHidden">
            <table cellspacing="0" cellpadding="0" border="0">
                <tbody>
                <tr>
                    <td><span>暂无数据</span></td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
    import Vue from 'vue';
    import moment from 'moment';
    import $ from 'jquery';

    export default {
        name: "TableByRealTime",
        props: [
            "realTimeData",
            "searchData"
        ],
        data() {
            return {
                table: {
                    tableId: 'realTimeTable',
                    tipId: 'realTimeTableTip',
                },
                realTimeColumn: [
                    {
                        title: '主机',
                        key: 'ip'
                    },
                    {
                        title: '应用',
                        key: 'application'
                    },
                    {
                        title: '组件',
                        key: 'component'
                    },
                    {
                        title: '站点ID',
                        key: 'siteId'
                    },
                    {
                        title: 'Action',
                        key: 'action'
                    },
                    {
                        title: 'ActionKey',
                        key: 'actionKey'
                    },
                    {
                        title: '请求开始时间',
                        key: 'beginTimeStr'
                    },
                    {
                        title: '请求结束时间',
                        key: 'endTimeStr'
                    },
                    {
                        title: '请求结果',
                        key: 'result'
                    },
                    {
                        title: '错误日志'
                    }
                ],
                realTimeGridData: [],
                dataLoading: false,
                tipHidden: false
            }
        },
        methods: {
            createTr(data) {
                let vm = this, table = $('#' + vm.table.tableId),
                    $tr = $(`<tr class="ivu-table-row"><td class=""><div class="ivu-table-cell"><span>${data.ip}</span></div></td><td class=""><div class="ivu-table-cell"><span>${data.application}</span></div></td><td class=""><div class="ivu-table-cell"><span>${data.component}</span></div></td><td class=""><div class="ivu-table-cell"><span>${data.siteId}</span></div></td><td class=""><div class="ivu-table-cell"><span>${data.action}</span></div></td><td class=""><div class="ivu-table-cell"><span>${data.actionKey}</span></div></td><td class=""><div class="ivu-table-cell"><span>${data.beginTimeStr}</span></div></td><td class=""><div class="ivu-table-cell"><span>${data.endTimeStr}</span></div></td><td class=""><div class="ivu-table-cell"><span>${data.result}</span></div></td></tr>`);
                if(data.errorInfo){
                    let error = data.errorInfo;
                    let popTipTd = Vue.extend({
                        data: function () {
                            return {
                                error: error,
                                popTipTransfer : true
                            }
                        },
                        template: `<td class="">
                                    <div class="ivu-table-cell">
                                        <span>
                                            <Poptip trigger="hover" placement="left-end"
                                                    width="1400" :transfer="popTipTransfer">
                                                <Button>查看异常</Button>
                                                <div class="api" slot="content">
                                                <table class="error-table">
                                                    <thead>
                                                        <tr>
                                                            <th>OwnerClass</th>
                                                            <th>ErrorMessage</th>
                                                            <th>Exception</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>${data.owner}</td>
                                                            <td>${error.errorMessage}</td>
                                                            <td>
                                                                <template
                                                                        v-for="(err,index) of error.exception"
                                                                        v-if="index < 5">
                                                                        className : {{err.className}},fileName : {{err.fileName}},lineNumber : {{err.lineNumber}},methodName : {{err.methodName}},nativeMethod : {{err.nativeMethod}}
                                                                        <br>
                                                                </template>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                </div>
                                            </Poptip>
                                        </span>
                                    </div>
                                   </td>`
                    });
                    $tr.append(new popTipTd().$mount().$el);
                    $tr.addClass('data-error');
                }else{
                    $('<td class=""></td>').appendTo($tr);
                    $tr.find('td').css({"-webkit-animation": "newData 7s 1 ease-in-out"});
                }

                if (table.css('display') === 'none') {
                    table.show();
                    vm.tipHidden = true;
                }
                table.find('tbody:first').prepend($tr);
            }
        },
        watch: {
            realTimeData: function (val, oldVal) {
                let vm = this, arr = [];
                vm.dataLoading = true;
                //vm.realTimeGridData = [];
                Object.keys(val).forEach((v) => {
                    let hosts = val[v], hostArr = Object.keys(hosts);
                    hostArr.forEach((host) => {
                        let applications = hosts[host], applicationArr = Object.keys(applications);
                        applicationArr.forEach((application) => {
                            if(vm.searchData.applications.length === 0 || (vm.searchData.applications.length > 0 && vm.searchData.applications.indexOf(application) != -1)) {
                                let components = applications[application], componentArr = Object.keys(components);
                                componentArr.forEach((component) => {
                                    let sites = components[component], siteArr = Object.keys(sites);
                                    siteArr.forEach((site) => {
                                        if(vm.searchData.siteId === '' || (vm.searchData.siteId != '' && site === vm.searchData.siteId)) {
                                            let actions = sites[site];
                                            actions.forEach((action) => {
                                                let data = {
                                                    ip: host,
                                                    application: application,
                                                    component: component,
                                                    siteId: site == -1 ? '' : site,
                                                    action: action.action,
                                                    actionKey: action.actionKey,
                                                    result: action.result,
                                                    beginTime: action.beginTime,
                                                    endTime: action.endTime,
                                                    beginTimeStr: moment(action.beginTime).format('YYYY-MM-DD HH:mm:ss'),
                                                    endTimeStr: moment(action.endTime).format('YYYY-MM-DD HH:mm:ss'),
                                                    errorInfo:action.errorInfo,
                                                    owner : action.owner
                                                };
                                                vm.createTr(data);
                                                //vm.realTimeGridData.splice(0, 0, data);
                                            });
                                        }
                                    });
                                });
                            }
                        });
                    });
                });
                vm.dataLoading = false;
            }
        }
    }
</script>