<style lang="less">
    @import 'monitor.less';
</style>
<template>
    <Row class="monitor-tabs">
        <ConsoleTabs :animated="false" type="card">
            <template v-for="(item, key,index) in appRelations">
                <ConsoleTabPane :label="label" :name="index + ''" :params="item" :labelText="key">
                    <monitor-table :appRelations="item" :keyName="key"  @load-data="loadData"></monitor-table>
                </ConsoleTabPane>
            </template>
        </ConsoleTabs>
    </Row>
</template>
<script>
    import ConsoleTabs from '../../../../components/tabs/consoleTabs';
    import monitorTable from './components/monitorTable.vue';
    import ConsoleTabPane from '../../../../components/tabs/consoleTabPane.vue';
    export default {
        name: 'monitorTab',
        components: {
            ConsoleTabs,ConsoleTabPane,monitorTable
        },
        data() {
            return {
                label: (h,param,labelText) => {
                     return h('div', [
                        h('Badge', {
                            props: {
                                count: param.length
                            }
                        }), h('span', labelText)
                    ]);
                },
                appRelations: []
            };
        },
        methods: {
            loadData() {
                let vm = this;
                vm.$http.get('/csboss/Monitor/Version.html', {async: false})
                    .then((response) => {
                            let monitorList = response.body;
                            vm.appRelations = monitorList[0];
                        },
                        (error) => {
                            console.log(error)
                        });
            }
        },
        beforeMount() {
            var vm = this;
            vm.loadData();
        }
    }
</script>