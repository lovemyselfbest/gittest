<!--
*
* @description: 组件监控
*
* @author: nick
*
* @create: 2018-05-20 16:08
-->
<style lang="less">
    @import 'monitor-comp.less';
</style>
<template>
    <Row>
        <Col span="8">
            <Card :style="headerStyle">
                <p slot="title">启用监控</p>
                <Form ref="enableForm" :model="enableForm" :label-width="80" :rules="ruleEnable" inline>
                    <FormItem label="监控类型" prop="cateSearch" style="width:70%;">
                        <Select v-model="enableForm.cateSearch" multiple style="width:100%;">
                            <Option value="MQProducer">MQProducer</Option>
                            <Option value="Web">Web</Option>
                            <Option value="Scheduler">Scheduler</Option>
                            <Option value="Service">Service</Option>
                            <Option value="API">API</Option>
                            <Option value="MQConsumer">MQConsumer</Option>
                            <Option value="Cache">Cache</Option>
                        </Select>
                    </FormItem>
                    <FormItem style="text-align: center;width:20%;">
                        <Button type="primary" @click="handleSubmit('enableForm')">提交</Button>
                    </FormItem>
                </Form>
            </Card>
        </Col>
        <Col span="8">
            <Card :style="headerStyle" v-if="$root.hasActionPermissions($attrs.permission,'订阅数据')">
                <p slot="title">订阅数据</p>
                <Form ref="subscriptionForm" :model="subscriptionForm" :label-width="80" :rules="ruleSubscription"
                      inline>
                    <FormItem label="监控时间" prop="dateSearch" style="width:70%;">
                        <RadioGroup v-model="subscriptionForm.dateSearch">
                            <Radio label="实时"></Radio>
                            <Radio label="5分钟"></Radio>
                            <Radio label="1小时"></Radio>
                            <Radio label="1天"></Radio>
                        </RadioGroup>
                    </FormItem>
                    <FormItem style="text-align: center;width:20%;">
                        <Button type="primary" @click="handleSubmit('subscriptionForm')">提交</Button>
                    </FormItem>
                </Form>
            </Card>
        </Col>
        <Col span="8">
            <Card :style="headerStyle">
                <p slot="title">筛选数据</p>
                <Form ref="searchForm" :model="searchForm" :label-width="80" :rules="ruleSearch" inline>
                    <FormItem label="应用名称" style="width:70%;">
                        <Select v-model="searchForm.applicationSearch" multiple style="width:100%;">
                            <Option value="ACenter">ACenter</Option>
                            <Option value="api-service">ApiService</Option>
                            <Option value="boss">Boss</Option>
                            <Option value="boss-api">BossApi</Option>
                            <Option value="ccenter">CCenter</Option>
                            <Option value="lottery">Lottery</Option>
                            <Option value="lottery-mobile">LotteryMobile</Option>
                            <Option value="mcenter">MCenter</Option>
                            <Option value="mdcenter">MDCenter</Option>
                            <Option value="mobile">Mobile</Option>
                            <Option value="mobile-api">MobileApi</Option>
                            <Option value="msites">MSites</Option>
                            <Option value="pcenter">PCenter</Option>
                            <Option value="tcenter">TCenter</Option>
                            <Option value="gamebox-service">Service</Option>
                            <Option value="gamebox-service-api">ServiceApi</Option>
                            <Option value="gamebox-activity">ServiceActivity</Option>
                            <Option value="gamebox-schedule">Schedule</Option>
                            <Option value="gamebox-cp-schedule">CPSchedule</Option>
                            <Option value="boss-service">BossService</Option>
                        </Select>
                    </FormItem>
                    <FormItem label="站点ID" prop="siteSearch" style="text-align: center;width:70%;">
                        <Input v-model="searchForm.siteSearch"/>
                    </FormItem>
                    <FormItem style="text-align: center;width:20%;">
                        <Button type="primary" @click="handleSubmit('searchForm')">提交</Button>
                    </FormItem>
                </Form>
            </Card>
        </Col>
        <Col span="24"
             style="margin-top:15px;" v-if="subscriptionForm.dateSearch === '实时'">
            <Card>
                <p slot="title">实时数据</p>
                <TableByRealTime :realTimeData="realTimeData" :searchData="searchData"></TableByRealTime>
            </Card>
        </Col>
        <Col span="24"
             style="margin-top:15px;">
            <Card v-if="subscriptionForm.dateSearch ==='5分钟'">
                <p slot="title">5分钟统计</p>
                <TableBy5min :fiveMinuteData="fiveMinuteData" :searchData="searchData"></TableBy5min>
            </Card>
            <Card v-if="subscriptionForm.dateSearch === '1小时'">
                <p slot="title">1小时统计</p>
                <TableBy1Hour :oneHourData="oneHourData" :searchData="searchData"></TableBy1Hour>
            </Card>
            <Card v-if="subscriptionForm.dateSearch === '1天'">
                <p slot="title">1天统计</p>
                <TableBy1Day :oneDayData="oneDayData" :searchData="searchData"></TableBy1Day>
            </Card>
        </Col>
    </Row>
</template>
<script>
    import Comet from '../../../../components/socket/Comet';
    import TableByRealTime from './components/TableByRealTime';
    import TableBy5min from './components/TableBy5min';
    import TableBy1Hour from './components/TableBy1Hour';
    import TableBy1Day from './components/TableBy1Day';

    export default {
        name: "monitor-comp",
        components: {TableByRealTime, TableBy5min, TableBy1Hour, TableBy1Day},
        data() {
            const validateDateSearch = (rule, value, callback) => {
                if (value.length === 0) {
                    callback(new Error('请选择监控时间'));
                } else {
                    callback();
                }
            };
            const validateCateSearch = (rule, value, callback) => {
                if (value.length === 0) {
                    callback(new Error('请选择监控类型'));
                } else {
                    callback();
                }
            };
            const validateSiteSearch = (rule, value, callback) => {
                if (value.length > 0 && isNaN(value)) {
                    callback(new Error('站点ID必须是数字'));
                } else {
                    callback();
                }
            };
            return {
                headerStyle: {
                    height: '200px'
                },
                isSubscribed: false,
                subscriptionForm: {
                    dateSearch: ''
                },
                searchForm: {
                    applicationSearch: [],
                    siteSearch: ''
                },
                enableForm: {
                    cateSearch: []
                },
                ruleSubscription: {
                    dateSearch: [
                        {validator: validateDateSearch, trigger: 'blur'}
                    ]
                },
                ruleEnable: {
                    cateSearch: [
                        {validator: validateCateSearch, trigger: 'blur'}
                    ]
                },
                ruleSearch: {
                    siteSearch: [
                        {validator: validateSiteSearch, trigger: 'blur'}
                    ]
                },
                realTimeData: [],
                fiveMinuteData: [],
                oneHourData: [],
                oneDayData: [],
                searchData : {
                    applications  : [],
                    siteId : ''
                }
            }
        },
        methods: {
            realTimeCallback(data) {
                console.log('realTimeCallback running!!');
                data = JSON.parse(data);
                this.realTimeData = data.body.datas;
            },
            fiveMinuteCallback(data) {
                console.log('fiveMinuteCallback running!!');
                //console.log(data);
                data = JSON.parse(data);
                this.fiveMinuteData = data.body.datas;

            },
            oneHourCallback(data) {
                console.log('oneHourCallback running!!');
                data = JSON.parse(data);
                this.oneHourData = data.body.datas;
            },
            oneDayCallback(data) {
                console.log('oneDayCallback running!!');
                data = JSON.parse(data);
                this.oneDayData = data.body.datas;

            },
            enableMonidtorCallback(data) {
                console.log('enableMonidtorCallback running!!');
                data = JSON.parse(data);
                this.$Message.success({
                    content: data.body.message,
                    duration: 3
                });
            },
            subscriptionCallback(data) {
                console.log('subscriptionCallback running!!');
                data = JSON.parse(data);

            },
            handleSubmit(name) {
                let vm = this;
                this.$refs[name].validate((valid) => {
                    if (valid) {
                        if (name === 'subscriptionForm') {
                            let commandBody = [];
                            switch (vm.subscriptionForm.dateSearch) {
                                case '实时' :
                                    commandBody.push("realTime");
                                    break;
                                case '5分钟' :
                                    commandBody.push("fiveMinute");
                                    break;
                                case '1小时' :
                                    commandBody.push("oneHour");
                                    break;
                                case '1天' :
                                    commandBody.push("oneDay");
                                    break;
                                default :
                                    break;
                            }
                            let comet = vm.$store.getters.getWebSocket;
                            comet.websocket.send(JSON.stringify({
                                type: "Command",
                                body: JSON.stringify({
                                    commandType: "Subscribe",
                                    commandBody: commandBody
                                })
                            }));
                            this.$Message.success('订阅成功!');
                        }
                        if (name === 'enableForm') {
                            //let commandBody = [];
                            let comet = vm.$store.getters.getWebSocket;
                            comet.websocket.send(JSON.stringify({
                                type: "Command",
                                body: JSON.stringify({
                                    commandType: "EnableMonitor",
                                    commandBody: vm.enableForm.cateSearch
                                })
                            }));
                            //this.$Message.success('启用成功!');
                        }
                        if(name === 'searchForm'){
                            vm.searchData.applications = vm.searchForm.applicationSearch;
                            vm.searchData.siteId = vm.searchForm.siteSearch;
                            this.$Message.success('设置成功!');
                        }
                    } else {
                    }
                })
            }
        },
        beforeMount() {
            let vm = this;
            Comet.init({
                isImmediatelyConnect: true,
                subscribes: [
                    {type: 'realTime', callback: vm.realTimeCallback},
                    {type: 'fiveMinute', callback: vm.fiveMinuteCallback},
                    {type: 'oneHour', callback: vm.oneHourCallback},
                    {type: 'oneDay', callback: vm.oneDayCallback},
                    {type: 'EnableMonitor', callback: vm.enableMonidtorCallback},
                    {type: 'subscription', callback: vm.subscriptionCallback}
                ],
                success: function () {
                    console.info('连接成功');
                    vm.$store.commit("setComet", Comet);
                },
                failure: function () {
                    console.info('连接失败');
                }
            });
        },
        destroyed() {
            this.$store.commit("disConnectSocket");
            console.info('断开连接');
        }
    }
</script>