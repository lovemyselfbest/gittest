<template>
    <!--<Table border :columns="monitorTableColumns" :data="monitorTableDatas"></Table>-->
    <div data-v-31848140="" class="ivu-table-wrapper">
        <div class="ivu-table ivu-table-border">
            <div class="ivu-table-header">
                <table cellspacing="0" cellpadding="0" border="0" style="width: 100%;">
                    <thead>
                    <tr>
                        <th class="">
                            <div class="ivu-table-cell"><span>appName</span></div>
                        </th>
                        <th class="">
                            <div class="ivu-table-cell"><span>IP</span></div>
                        </th>
                        <th class="">
                            <div class="ivu-table-cell"><span>hostName</span></div>
                        </th>
                        <th class="">
                            <div class="ivu-table-cell"><span>serviceName</span></div>
                        </th>
                        <th class="">
                            <div class="ivu-table-cell"><span>Version</span></div>
                        </th>
                        <th class="">
                            <div class="ivu-table-cell"><span>aviliable Version</span></div>
                        </th>
                    </tr>
                    </thead>
                </table>
            </div>
            <div class="ivu-table-body">
                <table cellspacing="0" cellpadding="0" border="0" style="width: 100%;">
                    <tbody class="ivu-table-tbody">
                    <template v-for="(item, index) in monitorTableDatas">
                        <tr class="ivu-table-row">
                            <td class="" v-if="index == 0" :rowspan="monitorTableDatas.length">
                                <div class="ivu-table-cell">
                                    <div><strong>{{item.appName}}</strong></div>
                                </div>
                            </td>
                            <td class="" v-if="index == 0" :rowspan="monitorTableDatas.length">
                                <div class="ivu-table-cell"><span>{{item.IP}}</span>
                                </div>
                            </td>
                            <td class="" v-if="index == 0" :rowspan="monitorTableDatas.length">
                                <div class="ivu-table-cell"><span>{{item.hostName}}</span>
                                    <Button type="primary" :loading="item.loadings.loading1" v-on:click="appSwitch(index,item)"
                                            v-if="item.isService != null && !item.isService">
                                        <span v-if="!item.loadings.loading1">启用/停用</span>
                                        <span v-else>操作中...</span>
                                    </Button>
                                </div>
                            </td>
                            <td class="">
                                <div class="ivu-table-cell"><span>{{item.serviceName}}</span></div>
                            </td>
                            <td class="">
                                <div class="ivu-table-cell"><span>{{item.Version}}</span></div>
                            </td>
                            <td class="">
                                <div class="ivu-table-cell" v-for="(map, key) in item.serviceVersionMap">
                                    <li><span>{{map.hostIp}}:{{map.port}} {{map.version}} {{map.applicationName}}</span>
                                        <Button type="info" size="small" :loading="item.loadings.loading2" v-on:click="changeVersion($event,index,map)"
                                                v-if="key != item.Version">
                                            <span v-if="!item.loadings.loading2">切换至此版本</span>
                                            <span v-else>操作中...</span>
                                        </Button>
                                        <Button type="error" size="small" :loading="item.loadings.loading3" v-on:click="removeInvoke($event,index,map)">
                                            <span v-if="!item.loadings.loading3">停用</span>
                                            <span v-else>操作中...</span>
                                        </Button>
                                    </li>
                                </div>
                            </td>
                        </tr>
                    </template>
                    </tbody>
                </table>
            </div>
            <div class="ivu-table-tip" style="display: none;">
                <table cellspacing="0" cellpadding="0" border="0">
                    <tbody>
                    <tr>
                        <td><span>暂无筛选结果</span></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "monitorTable",
        props: {
            appRelations: Array,
            keyName: String
        },
        data() {
            return {
                monitorTableColumns: [
                    {
                        title: 'appName',
                        key: 'appName'
                    },
                    {
                        title: 'IP',
                        key: 'IP'
                    },
                    {
                        title: 'hostName',
                        key: 'hostName'
                    },
                    {
                        title: 'serviceName',
                        key: 'serviceName'
                    },
                    {
                        title: 'Version',
                        key: 'Version'
                    },
                    {
                        title: 'aviliable Version',
                        key: 'aviliableVersion'
                    },

                ],
                monitorTableDatas: []
            }
        },
        methods: {
            appSwitch(index,appData) {
                let vm = this;
                appData.loadings.loading1 = true;
                vm.$http.post("/csboss/Monitor/appSwitch.html",{
                    appKey:appData.appKey,
                    hostIp:appData.hostIp,
                    versionName:appData.version,
                    isServer : "false",
                    applicationName:appData.appName}, {emulateJSON: true}).then((response) => {
                        let body = response.body;
                        if(body == 'false'){
                            vm.$Message.error("操作失败");
                        }else{
                            vm.$Message.success("操作成功");
                            vm.$emit('load-data');
                        }
                        appData.loadings.loading1 = false;
                    },
                    (error) => {
                        vm.$Message.error("操作失败");
                        appData.loadings.loading1 = false;
                    });
            },
            removeInvoke(event,index,serviceData) {
                let vm = this;
                let appData = vm.monitorTableDatas[index];
                appData.loadings.loading3 = true;
                vm.$http.post("/csboss/Monitor/removeInvoke.html",{
                    appKey:serviceData.appKey,
                    hostIp:serviceData.hostIp,
                    versionName:serviceData.version,
                    serverApp:serviceData.applicationName}, {emulateJSON: true}).then((response) => {
                        let body = response.body;
                        if(body == 'false'){
                            vm.$Message.error("操作失败");
                        }else{
                            vm.$Message.success("操作成功");
                            vm.$emit('load-data');
                        }
                        appData.loadings.loading3 = false;
                    },
                    (error) => {
                        vm.$Message.error("操作失败");
                        appData.loadings.loading3 = false;
                    });
            },
            changeVersion(event,index,serviceData) {
                let vm = this;
                let appData = vm.monitorTableDatas[index];
                appData.loadings.loading2 = true;
                this.$http.post("/csboss/Monitor/ChangeVersion.html",{
                    appKey:serviceData.appKey,
                    hostIp:serviceData.hostIp,
                    versionName:serviceData.version,
                    serverApp:serviceData.applicationName}, {emulateJSON: true}).then((response) => {
                        let body = response.body;
                        if(body == 'false'){
                            vm.$Message.error("操作失败");
                        }else{
                            vm.$Message.success("操作成功");
                            vm.$emit('load-data');
                        }
                        appData.loadings.loading2 = false;
                    },
                    (error) => {
                        vm.$Message.error("操作失败");
                        appData.loadings.loading2 = false;
                    });
            }
        },
        beforeMount() {
            let vm = this, props = vm.$props, appData = props.appRelations;
            let data;
            if (appData && appData.length > 0) {
                appData.forEach((item) => {
                    data = {
                        appName: props.keyName,
                        IP: item.hostIp,
                        hostName: item.hostName,
                        serviceName: item.serviceName,
                        Version: item.version,
                        isService: item.isService,
                        serviceVersionMap: item.serviceVersionMap,
                        loadings : {
                            loading1 : false,loading2 : false,loading3 : false
                        }
                    };
                    vm.monitorTableDatas.push(data);
                })

            } else {
                data = {
                    appName: props.keyName
                };
                vm.monitorTableDatas.push(data);
            }
        }
    }
</script>

<style scoped>

</style>