const socket = {
    state: {
        Comet: null
    },
    mutations: {
        setComet: (state, comet) => {
            state.Comet = comet;
        },
        disConnectSocket: (state) => {
            if (state.Comet)
                state.Comet.websocket.close();
        }
    },
    getters: {
        getWebSocket: (state) => {
            return state.Comet;
        }
    }
};
export default socket;
